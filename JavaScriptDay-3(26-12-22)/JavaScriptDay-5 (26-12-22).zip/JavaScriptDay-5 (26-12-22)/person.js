const name = "Jesse";
const age = 40;

export { name, age };